#!/bin/bash
set -e

mkdir -p /data/postgres /data/nginx
chmod 700 /data/postgres

cat > /data/nginx/default.conf <<'EOF'
server {
    listen 80;
    server_name localhost;

    resolver 127.0.0.11 valid=10s ipv6=off;

    set $frontend_upstream http://frontend:80;
    set $backend_upstream  http://backend:8000;
    set $adminer_upstream  http://adminer:8080;

    proxy_set_header Host              $host;
    proxy_set_header X-Real-IP         $remote_addr;
    proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;

    client_max_body_size 20m;

    location / {
        proxy_pass $frontend_upstream;
    }

    location /api {
        proxy_pass $backend_upstream;
    }

    location /docs {
        proxy_pass $backend_upstream;
    }

    location /redoc {
        proxy_pass $backend_upstream;
    }

    location = /adminer {
        return 301 /adminer/;
    }

    location /adminer/ {
        rewrite ^/adminer/(.*)$ /$1 break;
        proxy_pass $adminer_upstream;
    }
}
EOF
chmod 644 /data/nginx/default.conf
echo "Конфиг nginx сгенерирован: /data/nginx/default.conf"
