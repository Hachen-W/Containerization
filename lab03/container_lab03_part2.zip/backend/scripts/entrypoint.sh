#!/bin/bash
set -e

export SECRET_KEY="$(cat /run/secrets/secret_key)"
export FIRST_SUPERUSER_PASSWORD="$(cat /run/secrets/first_superuser_password)"

DB_PASSWORD="$(cat /run/secrets/db_password)"
export DATABASE_URL="postgresql+psycopg://${POSTGRES_USER}:${DB_PASSWORD}@${POSTGRES_SERVER}:${POSTGRES_PORT}/${POSTGRES_DB}"

exec "$@"
