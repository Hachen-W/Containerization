#!/bin/bash
set -e
SECRETS_DIR=/home/vagrant/app/secrets
mkdir -p "$SECRETS_DIR"
chmod 700 "$SECRETS_DIR"

gen() {
  local f="$SECRETS_DIR/$1"
  if [ ! -s "$f" ]; then
    tr -dc 'A-Za-z0-9' </dev/urandom | head -c "$2" > "$f"
    echo "Секрет $1 сгенерирован"
  fi
  chown root:root "$f"
  chmod 600 "$f"
}

gen db_password              40
gen secret_key               64
gen first_superuser_password 32

chown 70:70 "$SECRETS_DIR/db_password"
