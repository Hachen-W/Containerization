#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

chattr -i /etc/resolv.conf 2>/dev/null || true
rm -f /etc/resolv.conf
printf 'nameserver 10.0.2.3\nnameserver 77.88.8.8\nnameserver 8.8.8.8\noptions timeout:2 attempts:3\n' > /etc/resolv.conf
chattr +i /etc/resolv.conf 2>/dev/null || true

retry() {
  for attempt in 1 2 3 4 5; do
    if "$@"; then return 0; fi
    echo "Попытка $attempt не удалась: $* — повтор через 15 с"
    sleep 15
  done
  return 1
}

if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  retry apt-get update -y
  retry apt-get install -y ca-certificates curl gnupg

  install -m 0755 -d /etc/apt/keyrings
  retry bash -c 'curl -fsSL https://download.docker.com/linux/debian/gpg | gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg'
  chmod a+r /etc/apt/keyrings/docker.gpg

  CODENAME=$(. /etc/os-release && echo "$VERSION_CODENAME")
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian $CODENAME stable" > /etc/apt/sources.list.d/docker.list

  retry apt-get update -y
  retry apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

mkdir -p /etc/docker
printf '{\n  "dns": ["10.0.2.3", "77.88.8.8", "8.8.8.8"]\n}\n' > /etc/docker/daemon.json
systemctl daemon-reload
systemctl enable docker
systemctl restart docker
usermod -aG docker vagrant

if ! swapon --show | grep -q /swapfile; then
  AVAIL_GB=$(df -BG --output=avail / | tail -1 | tr -dc '0-9')
  if [ "${AVAIL_GB:-0}" -gt 8 ]; then
    fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
    grep -q /swapfile /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  fi
fi
