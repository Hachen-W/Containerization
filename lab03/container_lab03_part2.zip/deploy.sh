#!/bin/bash
set -e
cd /home/vagrant/app

retry() {
  for attempt in 1 2 3 4 5; do
    if "$@"; then return 0; fi
    echo "Попытка $attempt не удалась: $* — повтор через 15 с"
    sleep 15
  done
  return 1
}

for i in $(seq 1 24); do
  getent hosts registry-1.docker.io >/dev/null && break
  echo "DNS: registry-1.docker.io недоступен, ожидание..."
  sleep 5
done

rm -f compose.yml compose.override.yml compose.deploy.yml
docker compose -f docker-compose.yml down 2>/dev/null || true

for img in python:3.14 oven/bun:1 nginx:alpine postgres:15-alpine adminer:latest ghcr.io/astral-sh/uv:0.9.26; do
  echo "Загрузка образа $img"
  retry docker pull -q "$img"
done

echo "Сборка frontend"
retry docker compose -f docker-compose.yml build frontend
echo "Сборка backend"
retry docker compose -f docker-compose.yml build backend

echo "Запуск контейнеров"
docker compose -f docker-compose.yml up -d
