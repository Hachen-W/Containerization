#!/bin/bash

for image in "$@"; do
  for try in 1 2 3 4 5; do
    docker pull -q "$image" && break
    echo "$image не скачался, пробую ещё раз"
    sleep 10
  done
  docker image inspect "$image" > /dev/null || exit 1
done
