#!/bin/bash
set -e

if ! command -v docker > /dev/null; then
  curl -fsSL https://get.docker.com | sh
fi

systemctl enable --now docker
