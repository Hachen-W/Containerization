#!/bin/bash
set -e

rm -f /vagrant/worker_token

if ! docker node ls > /dev/null 2>&1; then
  docker swarm init --advertise-addr "$1"
fi

docker swarm join-token worker -q > /vagrant/worker_token

for stack in viz portainer web; do
  docker stack deploy -c /vagrant/stacks/$stack.yml $stack
done
