#!/bin/bash
set -e

if docker info 2> /dev/null | grep -q "Swarm: active"; then
  exit 0
fi

while [ ! -f /vagrant/worker_token ]; do
  sleep 2
done

docker swarm join --token "$(cat /vagrant/worker_token)" "$1:2377"
